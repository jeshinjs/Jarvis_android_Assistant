@echo off
setlocal enabledelayedexpansion

title Building Jarvis Android APK
echo ========================================================
echo               J.A.R.V.I.S. APK BUILDER
echo ========================================================
echo.

cd /d "%~dp0android"

echo [*] Checking Java environment...
where java >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Java JDK 17 or higher was not found in your PATH.
    echo Please ensure Java 17 is installed and configured.
    echo.
    pause
    exit /b 1
)

echo [*] Compiling and assembling APK with Gradle...
echo.
call gradlew.bat assembleDebug

if %errorlevel% neq 0 (
    echo.
    echo ========================================================
    echo [FAILED] Build failed! Check the error logs above.
    echo ========================================================
    echo.
    pause
    exit /b %errorlevel%
)

cd /d "%~dp0"
set "OUTPUT_APK=android\app\build\outputs\apk\debug\app-debug.apk"
set "DEST_APK=Jarvis.apk"

if exist "%OUTPUT_APK%" (
    copy /y "%OUTPUT_APK%" "%DEST_APK%" >nul
    echo.
    echo ========================================================
    echo [SUCCESS] APK built successfully!
    echo.
    echo Saved to: %~dp0%DEST_APK%
    echo ========================================================
    echo.
    
    echo Would you like to install it to your connected phone now? [Y/N]
    set /p INSTALL_CHOICE="Choice: "
    if /i "!INSTALL_CHOICE!"=="Y" (
        where adb >nul 2>nul
        if !errorlevel! equ 0 (
            echo [*] Installing to connected Android device...
            adb install -r "%DEST_APK%"
        ) else if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" (
            echo [*] Installing to connected Android device via Android SDK...
            "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" install -r "%DEST_APK%"
        ) else (
            echo [!] adb not found in PATH or Android SDK. Skipping direct install.
        )
    )
) else (
    echo [ERROR] Could not find output APK at %OUTPUT_APK%.
)

echo.
echo Done. Press any key to exit.
pause >nul
