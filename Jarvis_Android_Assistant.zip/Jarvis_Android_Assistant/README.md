# J.A.R.V.I.S. Standalone Android Voice Agent

A **100% standalone, real-time voice assistant** for Android that connects **directly to Google's Gemini 2.0 Multimodal Live API**.

---

## 1-Click Setup & Build Scripts

In the project root, you have two simple batch scripts:

1. **[`install_requirements.bat`](file:///c:/projects/Jarvis_v1_a/install_requirements.bat)** (Automated Setup):
   - Double-click to automatically check and install all requirements (Java OpenJDK 17, Android Platform Tools / `adb`, Gradle environment, and `.env` setup) using the Windows Package Manager.
2. **[`build_apk.bat`](file:///c:/projects/Jarvis_v1_a/build_apk.bat)** (1-Click APK Builder):
   - Double-click to compile and assemble the app.
   - Automatically outputs **[`Jarvis.apk`](file:///c:/projects/Jarvis_v1_a/Jarvis.apk)** directly in the root folder.
   - Prompts you to optionally install it straight to any connected Android device.

---

## Configuration

Edit **[`.env`](file:///c:/projects/Jarvis_v1_a/.env)** in the root folder:

```env
# Google Gemini API Key from Google AI Studio
GEMINI_API_KEY=your_key_here

# Default Voice Persona (Aoede, Puck, Charon, Kore, Fenrir)
GEMINI_VOICE=Aoede
```

---

## How to Use on Your Phone

1. Install and open the **Jarvis** app on your phone.
2. The app is pre-configured with your Google Gemini API key (you can also view or update it anytime by tapping **KEY / VOICE** in the top right).
3. Tap **INITIALIZE JARVIS**.
4. Grant microphone permissions when prompted.
5. As soon as the badge turns **ONLINE // LISTENING**, speak into your phone naturally. Jarvis will respond to you in real-time across multiple turns!
"# Jarvis_android_Assistant" 
