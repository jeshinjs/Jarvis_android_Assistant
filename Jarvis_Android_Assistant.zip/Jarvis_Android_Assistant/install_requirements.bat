@echo off
setlocal enabledelayedexpansion

title Jarvis Android Agent - Requirements Installer
echo ========================================================
echo        J.A.R.V.I.S. AUTOMATED REQUIREMENTS SETUP
echo ========================================================
echo.

:: 1. Check & Install Java JDK 17
echo [1/4] Checking Java JDK 17+...
where java >nul 2>nul
if !errorlevel! equ 0 (
    echo       [OK] Java is already installed.
    java -version 2>&1 | findstr /i "version"
) else (
    echo       [!] Java not found. Installing OpenJDK 17 via Windows Package Manager...
    winget install EclipseAdoptium.Temurin.17.JDK -e --accept-package-agreements --accept-source-agreements
    if !errorlevel! equ 0 (
        echo       [OK] Java JDK 17 installed successfully.
    ) else (
        echo       [ERROR] Failed to install Java automatically.
        echo       Please manually install JDK 17 from: https://adoptium.net/
    )
)
echo.

:: 2. Check & Install Android Platform Tools (adb)
echo [2/4] Checking Android Platform Tools [adb]...
where adb >nul 2>nul
if !errorlevel! equ 0 (
    echo       [OK] adb is already available in PATH.
) else if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" (
    echo       [OK] adb found in Android SDK directory.
) else (
    echo       [!] adb not found. Installing Android Platform Tools...
    winget install Google.PlatformTools -e --accept-package-agreements --accept-source-agreements
    if !errorlevel! equ 0 (
        echo       [OK] Android Platform Tools installed.
    ) else (
        echo       [!] Notice: You can also install Android Studio for the full SDK.
    )
)
echo.

:: 3. Check Android SDK / Android Studio
echo [3/4] Checking Android SDK...
if exist "%LOCALAPPDATA%\Android\Sdk" (
    echo       [OK] Android SDK detected at %LOCALAPPDATA%\Android\Sdk
) else if defined ANDROID_HOME (
    echo       [OK] Android SDK detected at %ANDROID_HOME%
) else (
    echo       [!] Android SDK not found in default locations.
    echo       Would you like to install Android Studio now? [Y/N]
    set /p INSTALL_STUDIO="Choice: "
    if /i "!INSTALL_STUDIO!"=="Y" (
        echo       Installing Android Studio via winget...
        winget install Google.AndroidStudio -e --accept-package-agreements --accept-source-agreements
    )
)
echo.

:: 4. Verify Configuration File (.env)
echo [4/4] Checking configuration file [.env]...
if exist "%~dp0.env" (
    echo       [OK] Configuration file .env is present.
) else (
    echo       [!] .env not found. Creating from .env.example...
    if exist "%~dp0.env.example" (
        copy /y "%~dp0.env.example" "%~dp0.env" >nul
        echo       [OK] Created .env file.
    )
)
echo.

:: 5. Initialize Gradle Wrapper
echo [*] Pre-fetching Gradle build environment...
cd /d "%~dp0android"
call gradlew.bat --version >nul 2>nul
if !errorlevel! equ 0 (
    echo       [OK] Gradle build environment initialized.
) else (
    echo       [!] Gradle will download on first build.
)
cd /d "%~dp0"

echo.
echo ========================================================
echo [SUCCESS] Requirements setup completed!
echo You can now double-click 'build_apk.bat' to build the APK.
echo ========================================================
echo.
pause
