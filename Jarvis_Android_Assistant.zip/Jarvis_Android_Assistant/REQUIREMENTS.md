# System & Development Requirements

To build and run the **J.A.R.V.I.S. Android Voice Agent**, your system and device require the following:

---

### 1. Build Machine (PC / Laptop)

| Component | Minimum Version | Notes |
| :--- | :--- | :--- |
| **Operating System** | Windows 10/11, macOS, or Linux | Windows `.bat` script provided for 1-click build. |
| **Java Development Kit (JDK)** | **JDK 17** (or newer) | Recommended: [Eclipse Temurin OpenJDK 17](https://adoptium.net/temurin/releases/). |
| **Android SDK** | API Level 26+ (Target: API 36) | Installed via Android Studio or Android SDK CLI. |
| **Gradle** | Bundled via `gradlew` | No separate Gradle installation needed. |
| **ADB (Platform Tools)** | Latest | Optional, used by `build_apk.bat` to auto-install APK to your phone. |

---

### 2. Android Phone

| Component | Minimum Version | Notes |
| :--- | :--- | :--- |
| **Android OS** | Android 8.0 (API 26) or higher | Recommended: Android 12+ for optimal hardware AEC. |
| **Hardware** | Microphone & Speaker | Required for bidirectional real-time audio. |
| **Network** | Active Wi-Fi or Mobile 5G/4G | Direct secure WebSocket access to Google Gemini. |

---

### 3. API Requirements

| Service | Details |
| :--- | :--- |
| **Google Gemini API Key** | Free tier or pay-as-you-go key from [Google AI Studio](https://aistudio.google.com/). |
| **Supported Model** | `models/gemini-2.5-flash-native-audio-preview-12-2025` (Multimodal Live API). |

---

### 4. 1-Click Build

Double-click [`build_apk.bat`](file:///c:/projects/Jarvis_v1_a/build_apk.bat) in the project root:
1. Compiles the Android project with Gradle.
2. Generates the APK.
3. Automatically copies it to `Jarvis.apk` in the root folder.
4. Prompts you to optionally install it directly to any USB-connected phone.
