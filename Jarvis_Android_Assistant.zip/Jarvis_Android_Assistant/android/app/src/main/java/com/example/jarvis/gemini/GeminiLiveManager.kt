package com.example.jarvis.gemini

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed interface JarvisState {
    object Disconnected : JarvisState
    object Connecting : JarvisState
    object Connected : JarvisState
    object JarvisSpeaking : JarvisState
    object UserSpeaking : JarvisState
    data class Error(val message: String) : JarvisState
}

class GeminiLiveManager {

    private val tag = "GeminiLiveManager"
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    private val _state = MutableStateFlow<JarvisState>(JarvisState.Disconnected)
    val state: StateFlow<JarvisState> = _state.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .pingInterval(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var webSocket: WebSocket? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var recordingJob: Job? = null
    private var playbackJob: Job? = null

    // Channel for non-blocking audio playback decoupling
    private val audioPlaybackChannel = Channel<ByteArray>(Channel.UNLIMITED)

    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null

    private var activeApiKey: String = ""
    private var activeVoice: String = "Aoede"

    // Audio recording configuration (16kHz, 16-bit, Mono PCM)
    private val sampleRateIn = 16000
    private val channelConfigIn = AudioFormat.CHANNEL_IN_MONO
    private val audioFormatIn = AudioFormat.ENCODING_PCM_16BIT

    // Audio playback configuration (Gemini outputs 24kHz, 16-bit, Mono PCM)
    private val sampleRateOut = 24000
    private val channelConfigOut = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormatOut = AudioFormat.ENCODING_PCM_16BIT

    fun connect(apiKey: String, voiceName: String = "Aoede") {
        if (_state.value is JarvisState.Connecting || _state.value is JarvisState.Connected) {
            return
        }

        if (apiKey.isBlank()) {
            _state.value = JarvisState.Error("Gemini API key is required")
            return
        }

        activeApiKey = apiKey
        activeVoice = voiceName

        _state.value = JarvisState.Connecting

        // Initialize Audio Playback (AudioTrack) & start background playback consumer
        initAudioTrack()
        startPlaybackConsumer()

        // Build WebSocket URL
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.i(tag, "WebSocket connected to Gemini Live API. Sending setup...")
                _state.value = JarvisState.Connecting

                // Send Setup configuration message
                sendSetupMessage(ws, voiceName)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onMessage(ws: WebSocket, bytes: okio.ByteString) {
                handleIncomingMessage(bytes.utf8())
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(tag, "WebSocket failure: ${t.message}", t)
                _state.value = JarvisState.Error(t.localizedMessage ?: "Connection failure")
                cleanupAudio()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.i(tag, "WebSocket closed ($code): $reason")
                if (code != 1000) {
                    _state.value = JarvisState.Error("Closed ($code): $reason")
                } else {
                    _state.value = JarvisState.Disconnected
                }
                cleanupAudio()
            }
        })
    }

    private fun sendSetupMessage(ws: WebSocket, voiceName: String) {
        try {
            val setupJson = JSONObject().apply {
                put("setup", JSONObject().apply {
                    put("model", "models/gemini-2.5-flash-native-audio-preview-12-2025")
                    put("generationConfig", JSONObject().apply {
                        put("responseModalities", JSONArray().apply { put("AUDIO") })
                        put("speechConfig", JSONObject().apply {
                            put("voiceConfig", JSONObject().apply {
                                put("prebuiltVoiceConfig", JSONObject().apply {
                                    put("voiceName", voiceName)
                                })
                            })
                        })
                    })
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "You are Jarvis, a highly intelligent, witty, concise, and helpful voice AI companion. You are speaking with the user in real time over voice. Keep your answers conversational, natural, and brief (1 to 3 sentences). Do not read markdown aloud.")
                            })
                        })
                    })
                })
            }
            ws.send(setupJson.toString())
            Log.i(tag, "Setup message dispatched to Gemini")
        } catch (e: Exception) {
            Log.e(tag, "Failed to send setup message", e)
        }
    }

    private fun handleIncomingMessage(text: String) {
        try {
            val json = JSONObject(text)

            // Setup complete confirmation
            if (json.has("setupComplete")) {
                Log.i(tag, "Gemini Live setupComplete confirmed! Starting audio recording...")
                _state.value = JarvisState.Connected
                startAudioRecording()
                return
            }

            // Check if user interrupted Jarvis speaking (Barge-in)
            if (json.has("serverContent")) {
                val serverContent = json.getJSONObject("serverContent")

                if (serverContent.optBoolean("interrupted", false)) {
                    Log.i(tag, "Barge-in detected: User interrupted Jarvis. Flushing audio playback.")
                    flushAudioPlayback()
                    _state.value = JarvisState.Connected
                    return
                }

                // Check for audio chunks from model turn
                if (serverContent.has("modelTurn")) {
                    val modelTurn = serverContent.getJSONObject("modelTurn")
                    val parts = modelTurn.optJSONArray("parts")

                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            if (part.has("inlineData")) {
                                val inlineData = part.getJSONObject("inlineData")
                                val base64Data = inlineData.optString("data")
                                if (base64Data.isNotBlank()) {
                                    val audioBytes = Base64.decode(base64Data, Base64.DEFAULT)
                                    // Non-blocking: enqueue audio chunk to playback consumer
                                    audioPlaybackChannel.trySend(audioBytes)
                                    _state.value = JarvisState.JarvisSpeaking
                                }
                            }
                        }
                    }
                }

                if (serverContent.optBoolean("turnComplete", false)) {
                    Log.i(tag, "Model turn complete.")
                    if (_state.value is JarvisState.JarvisSpeaking) {
                        _state.value = JarvisState.Connected
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error handling incoming message", e)
        }
    }

    private fun initAudioTrack() {
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRateOut,
            channelConfigOut,
            audioFormatOut
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(audioFormatOut)
                    .setSampleRate(sampleRateOut)
                    .setChannelMask(channelConfigOut)
                    .build()
            )
            .setBufferSizeInBytes(minBufferSize * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
    }

    private fun startPlaybackConsumer() {
        playbackJob?.cancel()
        playbackJob = scope.launch(Dispatchers.IO) {
            for (chunk in audioPlaybackChannel) {
                if (!isActive) break
                val track = audioTrack ?: continue
                try {
                    track.write(chunk, 0, chunk.size)
                } catch (e: Exception) {
                    Log.e(tag, "Error writing audio chunk to AudioTrack", e)
                }
            }
        }
    }

    private fun flushAudioPlayback() {
        try {
            // Drain queue
            while (audioPlaybackChannel.tryReceive().isSuccess) {}
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Log.e(tag, "Error flushing audio track", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudioRecording() {
        recordingJob?.cancel()

        recordingJob = scope.launch(Dispatchers.IO) {
            val minBufferSize = AudioRecord.getMinBufferSize(
                sampleRateIn,
                channelConfigIn,
                audioFormatIn
            )
            val bufferSize = minBufferSize.coerceAtLeast(3200)

            val record = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                sampleRateIn,
                channelConfigIn,
                audioFormatIn,
                bufferSize
            )
            audioRecord = record

            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(record.audioSessionId)?.apply {
                    enabled = true
                }
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(record.audioSessionId)?.apply {
                    enabled = true
                }
            }

            try {
                record.startRecording()
                Log.i(tag, "AudioRecord started at $sampleRateIn Hz")
            } catch (e: Exception) {
                Log.e(tag, "Failed to start AudioRecord", e)
                return@launch
            }

            val audioBuffer = ByteArray(bufferSize)

            while (isActive && record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val bytesRead = record.read(audioBuffer, 0, audioBuffer.size)

                // Echo suppression: Only stream mic when Jarvis is NOT actively speaking
                val isJarvisSpeaking = _state.value is JarvisState.JarvisSpeaking

                if (bytesRead > 0 && !_isMuted.value) {
                    var maxAmplitude = 0
                    for (i in 0 until bytesRead step 2) {
                        val sample = (audioBuffer[i + 1].toInt() shl 8) or (audioBuffer[i].toInt() and 0xFF)
                        val abs = Math.abs(sample.toShort().toInt())
                        if (abs > maxAmplitude) maxAmplitude = abs
                    }

                    // User voice activity detection
                    if (maxAmplitude > 2500) {
                        if (_state.value is JarvisState.Connected) {
                            _state.value = JarvisState.UserSpeaking
                        }
                    } else if (_state.value is JarvisState.UserSpeaking) {
                        _state.value = JarvisState.Connected
                    }

                    // Only stream if Jarvis is not vocalizing (prevents acoustic echo feedback loop)
                    if (!isJarvisSpeaking && (webSocket?.queueSize() ?: 0) < 64 * 1024) {
                        val base64Pcm = Base64.encodeToString(audioBuffer, 0, bytesRead, Base64.NO_WRAP)
                        val inputJson = JSONObject().apply {
                            put("realtimeInput", JSONObject().apply {
                                put("mediaChunks", JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("mimeType", "audio/pcm;rate=$sampleRateIn")
                                        put("data", base64Pcm)
                                    })
                                })
                            })
                        }
                        webSocket?.send(inputJson.toString())
                    }
                }
            }
        }
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
    }

    fun disconnect() {
        recordingJob?.cancel()
        recordingJob = null
        playbackJob?.cancel()
        playbackJob = null

        try {
            webSocket?.close(1000, "User disconnected")
            webSocket = null
        } catch (e: Exception) {
            Log.e(tag, "Error closing websocket", e)
        }

        cleanupAudio()
        _state.value = JarvisState.Disconnected
    }

    private fun cleanupAudio() {
        try {
            recordingJob?.cancel()
            recordingJob = null
            playbackJob?.cancel()
            playbackJob = null

            echoCanceler?.release()
            echoCanceler = null
            noiseSuppressor?.release()
            noiseSuppressor = null

            audioRecord?.let {
                try {
                    if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        it.stop()
                    }
                } catch (ignored: Throwable) {}
                try {
                    it.release()
                } catch (ignored: Throwable) {}
            }
            audioRecord = null

            audioTrack?.let {
                try {
                    if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        it.stop()
                    }
                } catch (ignored: Throwable) {}
                try {
                    it.release()
                } catch (ignored: Throwable) {}
            }
            audioTrack = null
        } catch (e: Exception) {
            Log.e(tag, "Error cleaning up audio components", e)
        }
    }
}
