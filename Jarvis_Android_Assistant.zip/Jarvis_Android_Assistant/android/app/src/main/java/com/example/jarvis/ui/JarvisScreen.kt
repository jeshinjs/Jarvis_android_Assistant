package com.example.jarvis.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.jarvis.gemini.GeminiLiveManager
import com.example.jarvis.gemini.JarvisState

@Composable
fun JarvisScreen(geminiManager: GeminiLiveManager) {
    val context = LocalContext.current
    val state by geminiManager.state.collectAsState()
    val isMuted by geminiManager.isMuted.collectAsState()

    // Persistent API key in SharedPreferences
    val prefs = remember { context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE) }
    val defaultKey = com.example.jarvis.BuildConfig.GEMINI_API_KEY.ifBlank { "AQ.Ab8RN6IQgp3wP2lWMg7ifp5qIss_LWO_3TxPTQR7UKdv5FW4fg" }
    val defaultVoice = com.example.jarvis.BuildConfig.GEMINI_VOICE.ifBlank { "Aoede" }

    var apiKey by remember {
        mutableStateOf(
            prefs.getString("gemini_api_key", defaultKey) ?: defaultKey
        )
    }
    var selectedVoice by remember {
        mutableStateOf(
            prefs.getString("gemini_voice", defaultVoice) ?: defaultVoice
        )
    }
    var showConfig by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            prefs.edit().putString("gemini_api_key", apiKey).apply()
            geminiManager.connect(apiKey, selectedVoice)
        }
    }

    fun handleConnectClick() {
        if (state is JarvisState.Disconnected || state is JarvisState.Error) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (hasPermission) {
                prefs.edit().putString("gemini_api_key", apiKey).apply()
                geminiManager.connect(apiKey, selectedVoice)
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        } else {
            geminiManager.disconnect()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "J.A.R.V.I.S.",
                        color = Color(0xFF00E5FF),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "STANDALONE NEURAL AGENT",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                TextButton(onClick = { showConfig = !showConfig }) {
                    Text(
                        text = if (showConfig) "CLOSE" else "KEY / VOICE",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Settings Card
            if (showConfig) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "GOOGLE GEMINI API KEY",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = {
                                apiKey = it
                                prefs.edit().putString("gemini_api_key", it).apply()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "VOICE PERSONA (Aoede, Puck, Charon, Kore, Fenrir)",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        OutlinedTextField(
                            value = selectedVoice,
                            onValueChange = { selectedVoice = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp
                            )
                        )
                    }
                }
            }

            // Central Glowing Jarvis Orb
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                JarvisOrb(state = state)
            }

            // Bottom Controls Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Status Badge
                StatusBadge(state)

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute/Unmute
                    val isConnected = state !is JarvisState.Disconnected && state !is JarvisState.Error

                    OutlinedButton(
                        onClick = { geminiManager.toggleMute() },
                        enabled = isConnected,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isMuted) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF1E293B)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isMuted) Color(0xFFEF4444) else Color(0xFF334155)
                        )
                    ) {
                        Text(
                            text = if (isMuted) "MIC OFF" else "MIC ON",
                            color = if (isMuted) Color(0xFFEF4444) else Color(0xFF00E5FF),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Main Connect/Disconnect Button
                    val isConnecting = state is JarvisState.Connecting
                    Button(
                        onClick = { handleConnectClick() },
                        enabled = !isConnecting,
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isConnected) Color(0xFFDC2626) else Color(0xFF00E5FF)
                        )
                    ) {
                        Text(
                            text = when {
                                isConnecting -> "INITIALIZING GEMINI..."
                                isConnected -> "TERMINATE LINK"
                                else -> "INITIALIZE JARVIS"
                            },
                            color = if (isConnected) Color.White else Color(0xFF090D16),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(state: JarvisState) {
    val (text, color) = when (state) {
        JarvisState.Disconnected -> "STANDBY // OFFLINE" to Color(0xFF64748B)
        JarvisState.Connecting -> "CONNECTING TO GEMINI LIVE..." to Color(0xFFF59E0B)
        JarvisState.Connected -> "ONLINE // LISTENING" to Color(0xFF00E5FF)
        JarvisState.JarvisSpeaking -> "JARVIS VOCALIZING..." to Color(0xFF10B981)
        JarvisState.UserSpeaking -> "USER SPEAKING..." to Color(0xFF38BDF8)
        is JarvisState.Error -> "FAULT: ${state.message}" to Color(0xFFEF4444)
    }

    Box(
        modifier = Modifier
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun JarvisOrb(state: JarvisState) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val coreColor by animateColorAsState(
        targetValue = when (state) {
            JarvisState.Disconnected -> Color(0xFF334155)
            JarvisState.Connecting -> Color(0xFFF59E0B)
            JarvisState.Connected -> Color(0xFF00E5FF)
            JarvisState.JarvisSpeaking -> Color(0xFF10B981)
            JarvisState.UserSpeaking -> Color(0xFF38BDF8)
            is JarvisState.Error -> Color(0xFFEF4444)
        },
        animationSpec = tween(400),
        label = "coreColor"
    )

    val isLive = state !is JarvisState.Disconnected && state !is JarvisState.Error

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(260.dp)
            .scale(if (isLive) pulseScale else 1f)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val maxRadius = size.minDimension / 2

            // Outer Orbit Ring
            drawCircle(
                color = coreColor.copy(alpha = 0.2f),
                radius = maxRadius * 0.95f,
                style = Stroke(width = 2.dp.toPx())
            )

            // Middle Glow Ring
            drawCircle(
                color = coreColor.copy(alpha = 0.35f),
                radius = maxRadius * 0.75f,
                style = Stroke(width = 3.dp.toPx())
            )

            // Inner Core Glowing Gradient
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.9f),
                        coreColor.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * 0.55f
                ),
                radius = maxRadius * 0.55f
            )

            // Center Core
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = maxRadius * 0.12f
            )
        }
    }
}
