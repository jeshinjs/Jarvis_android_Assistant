package com.example.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.jarvis.gemini.GeminiLiveManager
import com.example.jarvis.theme.JarvisTheme
import com.example.jarvis.ui.JarvisScreen

class MainActivity : ComponentActivity() {

    private lateinit var geminiManager: GeminiLiveManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        geminiManager = GeminiLiveManager()

        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF090D16)
                ) {
                    JarvisScreen(geminiManager = geminiManager)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        geminiManager.disconnect()
    }
}
